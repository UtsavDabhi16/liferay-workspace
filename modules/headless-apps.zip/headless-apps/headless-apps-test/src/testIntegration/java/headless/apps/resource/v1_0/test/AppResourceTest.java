package headless.apps.resource.v1_0.test;

import com.liferay.arquillian.extension.junit.bridge.junit.Arquillian;

import org.junit.Ignore;
import org.junit.runner.RunWith;

/**
 * @author root328
 */
@Ignore
@RunWith(Arquillian.class)
public class AppResourceTest extends BaseAppResourceTestCase {
}