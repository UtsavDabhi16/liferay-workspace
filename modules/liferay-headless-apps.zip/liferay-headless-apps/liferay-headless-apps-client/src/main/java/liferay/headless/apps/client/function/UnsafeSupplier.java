package liferay.headless.apps.client.function;

import javax.annotation.Generated;

/**
 * @author root328
 * @generated
 */
@FunctionalInterface
@Generated("")
public interface UnsafeSupplier<T, E extends Throwable> {

	public T get() throws E;

}